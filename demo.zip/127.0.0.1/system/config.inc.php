<?php
/*
Copyright 2015 Lcf.vs
 -
Released under the MIT license
 -
https://github.com/Lcfvs/PHPDOM
*/
require_once 'autoloader.php';

set_include_path(
    __DIR__ . '/classes;'
  . __DIR__ . '/classes/models'
);

define('PUBLIC_DIR', __DIR__ . '/../public');