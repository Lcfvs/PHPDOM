<?php
/*
Copyright 2015 Lcf.vs
 -
Released under the MIT license
 -
https://github.com/Lcfvs/PHPDOM
*/
namespace Controllers;

class Error extends Master
{
    public function __call($method, $arguments)
    {
        $method = str_replace('Action', '', $method);
        
        $this->_view->{$method}();
    }
}