<?php var_dump($_GET);
/*
Copyright 2015 Lcf.vs
 -
Released under the MIT license
 -
https://github.com/Lcfvs/PHPDOM
*/
require_once 'config.inc.php';

$uri = substr($_SERVER['REQUEST_URI'], 6);

$parts = explode('/', $uri);
$length = count($parts);

if ($length) { 
    $class_name = $parts[0];
    $controller = 'Controllers\\' . $class_name;
    $view = 'Views\\' . $class_name;
}

if (empty($class_name) || !is_readable(__DIR__ . '/Controllers/' . $class_name)){
    $controller = 'Controllers\\Index';
    $view = 'Views\\Index';
}

new $view(true, 'templates/documents/document.html');

$controller = new $controller();

if ($length > 1) {
    $action = $parts[1] . 'Action';
    
    if (!method_exists($controller, $action)) {
        $action = null;
    }
}

if (empty($action)) {
    $action = 'indexAction';
}

$controller->{$action}();