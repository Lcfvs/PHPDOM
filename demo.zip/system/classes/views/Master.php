<?php
/*
Copyright 2015 Lcf.vs
 -
Released under the MIT license
 -
https://github.com/Lcfvs/PHPDOM
*/
namespace Views; 
  
class Master extends \PHPDOM\HTML\Document 
{
    public function __construct($as_view, $template)
    {
        parent::__construct($as_view, $template);
        $this->title = 'Water Quality | ClouDIA';
        $this->addLink('../resources/css/reset.css');
        $this->addLink('../resources/css/style.css');
    }
    
    public function addLink($path) { 
        $this->select('head')->append([ 
            'tag' => 'link', 
            'attributes' => [ 
                'rel' => 'stylesheet', 
                'href' => $path 
            ] 
        ]); 
    }
    
    public function addHeader($path) {
        $header = $this->loadFragment($path);
        
        $this->body->appendChild($header); 
    } 
} 